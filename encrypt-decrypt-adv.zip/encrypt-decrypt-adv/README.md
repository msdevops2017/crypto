### Encrypt [POST]
Encrypts plain text using AES-256 and base64 encoding

+ key (required, string) - The password used for encrypting
+ text (required, string) - The text to be encoded

+ Request (application/json)

        {
            "text": "hello",
            "key": "password"
        }

+ Response 200 (application/json)

        {
            "text": "xxxxxxxxxxxxx",
            "timestamp": "2020-11-19T21:07:50Z"
        }
		
## Decryption Collection [/decrypt]

### Decrypt [POST]
Decrypts plain text using AES-256 and base64 encoding

+ key (required, string) - The password used for decrypting
+ text (required, string) - The text to be decoded

+ Request (application/json)

        {
            "text": "xxxxxxxxxx",
            "key": "password"
        }

+ Response 200 (application/json)

        {
            "text": "hello",
            "timestamp": "2020-11-19T21:07:50Z"
        }

		

